<?php 
$json='{"task":27}';
$data=json_decode($json,TRUE);
echo parcxSettings($data);
?>
