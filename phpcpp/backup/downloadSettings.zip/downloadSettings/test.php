<?php
$data["device_number"]="11";
$data["task"]=1;
echo downloadDeviceSettings($data);

?>